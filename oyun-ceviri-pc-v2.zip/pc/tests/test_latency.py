import http.client
import http.server
import threading
import unittest

import numpy as np

from capture import text_box
from glossary import BUILTIN_PHRASES
from pipeline import Pipeline
from session import DEFAULTS, build_draft, build_manager
from subtitle_core import TranslationError, TranslatorManager
from translators import GeminiTranslator, KeepAlivePool, PhrasebookTranslator


class TextBoxTests(unittest.TestCase):
    def test_empty_frame_has_no_text(self):
        self.assertIsNone(text_box(np.zeros((100, 300, 3), np.uint8)))

    def test_dim_noise_is_ignored(self):
        img = np.full((100, 300, 3), 90, np.uint8)
        self.assertIsNone(text_box(img))

    def test_box_surrounds_bright_text_with_padding(self):
        img = np.zeros((200, 400, 3), np.uint8)
        img[80:100, 50:250] = 255
        top, bottom, left, right = text_box(img, pad=10)
        self.assertEqual((70, 110, 40, 260), (top, bottom, left, right))

    def test_box_is_clamped_to_image(self):
        img = np.zeros((50, 60, 3), np.uint8)
        img[0:50, 0:60] = 255
        self.assertEqual((0, 50, 0, 60), text_box(img))

    def test_colored_text_counts(self):
        img = np.zeros((60, 200, 3), np.uint8)
        img[20:40, 20:150, 2] = 255  # saf kırmızı kanal
        self.assertIsNotNone(text_box(img))


class _Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    connections = set()
    close_next = False

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(n)
        _Handler.connections.add(self.client_address)
        out = b'{"ok":"' + body + b'"}'
        self.send_response(200)
        self.send_header("Content-Length", str(len(out)))
        if _Handler.close_next:
            _Handler.close_next = False
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        self.wfile.write(out)

    def log_message(self, *a):
        pass


class KeepAliveTests(unittest.TestCase):
    def setUp(self):
        _Handler.connections = set()
        _Handler.close_next = False
        self.srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.pool = KeepAlivePool(f"127.0.0.1:{self.srv.server_port}", 3.0, factory=http.client.HTTPConnection)

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()

    def test_one_connection_is_reused(self):
        for i in range(4):
            status, body = self.pool.post("/x", b"a%d" % i, {})
            self.assertEqual(200, status)
            self.assertIn("a%d" % i, body)
        self.assertEqual(1, len(_Handler.connections))

    def test_reconnects_when_server_closed_the_connection(self):
        _Handler.close_next = True
        self.pool.post("/x", b"1", {})
        status, _ = self.pool.post("/x", b"2", {})
        self.assertEqual(200, status)
        self.assertEqual(2, len(_Handler.connections))

    def test_unreachable_host_raises_oserror(self):
        pool = KeepAlivePool("127.0.0.1:1", 0.5, factory=http.client.HTTPConnection)
        with self.assertRaises(OSError):
            pool.post("/x", b"1", {})


class GeminiHttpMappingTests(unittest.TestCase):
    def _g(self, status, payload):
        g = GeminiTranslator("k", "m")
        g._post = lambda path, body: (status, payload)
        return g

    def test_success(self):
        ok = '{"candidates":[{"content":{"parts":[{"text":"Merhaba"}]}}]}'
        self.assertEqual("Merhaba", self._g(200, ok).translate("Hello"))

    def test_http_error_carries_status(self):
        with self.assertRaises(TranslationError) as cm:
            self._g(429, "{}").translate("Hello")
        self.assertEqual(429, cm.exception.code)

    def test_network_error_is_code_zero(self):
        g = GeminiTranslator("k", "m")

        def boom(path, body):
            raise OSError("x")

        g._post = boom
        with self.assertRaises(TranslationError) as cm:
            g.translate("Hello")
        self.assertEqual(0, cm.exception.code)


class _Inner:
    calls = 0

    def translate(self, t):
        _Inner.calls += 1
        return "MODEL " + t

    def close(self):
        pass


class PhrasebookTests(unittest.TestCase):
    def test_known_phrase_skips_the_model(self):
        _Inner.calls = 0
        pb = PhrasebookTranslator(_Inner(), BUILTIN_PHRASES)
        self.assertEqual("Bitir onu!", pb.translate("  FINISH HIM!! "))
        self.assertEqual(0, _Inner.calls)

    def test_unknown_phrase_goes_to_the_model(self):
        pb = PhrasebookTranslator(_Inner(), BUILTIN_PHRASES)
        self.assertEqual("MODEL something new here", pb.translate("something new here"))


class HybridHarness:
    def __init__(self, draft):
        self.now = 0
        self.shown = []
        self.jobs = []
        self.timings = []

        class Sink:
            def show(_s, t):
                self.shown.append(t)

            def clear(_s):
                self.shown.append("<clear>")

        self.text = ""
        mgr = TranslatorManager(None, _Inner(), clock=lambda: 0.0)
        self.p = Pipeline(
            grab=lambda: 1, ocr=lambda _f: self.text, manager=mgr, sink=Sink(), clock_ms=lambda: self.now,
            submit=self.jobs.append, draft=draft, on_timing=lambda k, ms: self.timings.append(k),
        )

    def see(self, text):
        self.text = text
        self.p.step()
        self.now += 100
        self.p.step()
        self.now += 100


class HybridTests(unittest.TestCase):
    def test_draft_shows_first_then_final_replaces_it(self):
        h = HybridHarness(draft=lambda t: "TASLAK " + t)
        h.see("Hello there friend")
        self.assertEqual(2, len(h.jobs))  # taslak + asıl çeviri
        h.jobs[0]()
        h.jobs[1]()
        self.assertEqual(["TASLAK Hello there friend", "MODEL Hello there friend"], h.shown)
        self.assertEqual(["taslak", "çeviri"], [k for k in h.timings if k != "OCR"])

    def test_draft_after_final_is_dropped(self):
        h = HybridHarness(draft=lambda t: "TASLAK " + t)
        h.see("Hello there friend")
        h.jobs[1]()
        h.jobs[0]()
        self.assertEqual(["MODEL Hello there friend"], h.shown)

    def test_stale_draft_is_dropped_after_new_line(self):
        h = HybridHarness(draft=lambda t: "TASLAK " + t)
        h.see("Hello there friend")
        old = list(h.jobs)
        h.jobs.clear()
        h.see("Totally different line now")
        for j in old:
            j()
        self.assertEqual([], h.shown)

    def test_identical_draft_and_final_are_not_shown_twice(self):
        h = HybridHarness(draft=lambda t: "MODEL " + t)
        h.see("Hello there friend")
        h.jobs[0]()
        h.jobs[1]()
        self.assertEqual(["MODEL Hello there friend"], h.shown)

    def test_failing_draft_is_ignored(self):
        def bad(_t):
            raise RuntimeError("model yok")

        h = HybridHarness(draft=bad)
        h.see("Hello there friend")
        h.jobs[0]()
        h.jobs[1]()
        self.assertEqual(["MODEL Hello there friend"], h.shown)

    def test_no_draft_means_single_job(self):
        h = HybridHarness(draft=None)
        h.see("Hello there friend")
        self.assertEqual(1, len(h.jobs))


class ModeTests(unittest.TestCase):
    def _s(self, **kw):
        return dict(DEFAULTS, gemini_key="KEY", **kw)

    def test_offline_mode_never_uses_gemini_and_knows_phrases(self):
        m = build_manager(self._s(mode="offline"), lambda _m: None)
        self.assertIsNone(m._primary)
        self.assertEqual("Bitir onu!", m.translate("Finish him"))

    def test_online_mode_keeps_gemini_primary(self):
        m = build_manager(self._s(mode="online"), lambda _m: None)
        self.assertIsNotNone(m._primary)

    def test_draft_only_in_hybrid_mode(self):
        self.assertIsNone(build_draft(self._s(mode="online"), lambda _m: None))
        self.assertIsNone(build_draft(self._s(mode="offline"), lambda _m: None))
        self.assertEqual("Bitir onu!", build_draft(self._s(mode="hybrid"), lambda _m: None).translate("finish him"))


if __name__ == "__main__":
    unittest.main()
