import os
import tempfile
import unittest
from unittest import mock

from cache import PersistentCache
from glossary import apply_replacements, parse_glossary, prompt_hint
from session import DEFAULTS, build_manager
from subtitle_core import TranslationError
from translators import (
    ArgosTranslator, CachingTranslator, ChainTranslator, GeminiTranslator, OllamaTranslator, ReplacingTranslator,
)


class Fake:
    def __init__(self, name, fail=None):
        self.name, self.fail, self.calls, self.closed, self.last = name, fail, 0, False, None

    def translate(self, text):
        self.calls += 1
        self.last = text
        if self.fail is not None:
            raise TranslationError(self.fail, "x")
        return f"{self.name}:{text}"

    def close(self):
        self.closed = True


class GlossaryTests(unittest.TestCase):
    def test_parse_both_formats(self):
        self.assertEqual({"Night City": "Night City", "Ripperdoc": "Siberdoktor"},
                         parse_glossary("Night City=Night City, Ripperdoc=Siberdoktor"))
        self.assertEqual({"a": "b", "c": "d"}, parse_glossary("a=b\nc = d\nbozuk\n=x"))
        self.assertEqual({}, parse_glossary(""))

    def test_replacements_word_boundary_case_insensitive_skip_same(self):
        m = {"ripperdoc": "siberdoktor", "Kano": "Kano"}
        self.assertEqual("The siberdoktor met Kano.", apply_replacements("The Ripperdoc met Kano.", m))
        self.assertEqual("Ripperdocs", apply_replacements("Ripperdocs", m))

    def test_prompt_hint_contains_keep_and_mapping(self):
        h = prompt_hint({"Kano": "Kano", "Sektor": "Sektör"})
        self.assertIn("Keep these names exactly as written: Kano", h)
        self.assertIn("Sektor => Sektör", h)
        self.assertIn("arkandayım", h)  # yerleşik deyimler


class CacheTests(unittest.TestCase):
    def setUp(self):
        self.cache = PersistentCache(os.path.join(tempfile.mkdtemp(), "c.db"))

    def test_roundtrip_ignores_punctuation_and_namespace_isolated(self):
        self.cache.put("g", "Thank you, both of you.", "İkinize de teşekkürler.")
        self.assertEqual("İkinize de teşekkürler.", self.cache.get("g", "thank you both of you"))
        self.assertIsNone(self.cache.get("other", "Thank you, both of you."))
        self.cache.clear()
        self.assertIsNone(self.cache.get("g", "Thank you, both of you."))

    def test_caching_translator_only_calls_inner_once(self):
        inner = Fake("g")
        c = CachingTranslator(inner, self.cache, "ns")
        self.assertEqual("g:hello there", c.translate("hello there"))
        self.assertEqual("g:hello there", c.translate("Hello there!"))
        self.assertEqual(1, inner.calls)

    def test_failures_are_not_cached(self):
        inner = Fake("g", fail=500)
        c = CachingTranslator(inner, self.cache, "ns")
        with self.assertRaises(TranslationError):
            c.translate("hello there")
        self.assertIsNone(self.cache.get("ns", "hello there"))


class ChainTests(unittest.TestCase):
    def test_falls_through_and_raises_last(self):
        a, b = Fake("a", fail=0), Fake("b")
        self.assertEqual("b:x", ChainTranslator([a, b]).translate("x"))
        with self.assertRaises(TranslationError):
            ChainTranslator([Fake("a", fail=0), Fake("b", fail=0)]).translate("x")
        with self.assertRaises(TranslationError):
            ChainTranslator([]).translate("x")

    def test_replacing_translator(self):
        inner = Fake("o")
        out = ReplacingTranslator(inner, {"Ripperdoc": "Siberdoktor"}).translate("The Ripperdoc is here")
        self.assertEqual("The Siberdoktor is here", inner.last)
        self.assertTrue(out.startswith("o:"))


class OllamaParseTests(unittest.TestCase):
    def test_parse(self):
        self.assertEqual("Merhaba", OllamaTranslator.parse('{"response":" \\"Merhaba\\" "}'))
        self.assertIsNone(OllamaTranslator.parse('{"response":"  "}'))
        self.assertIsNone(OllamaTranslator.parse("bozuk"))

    def test_connection_refused_becomes_translation_error(self):
        t = OllamaTranslator("m", url="http://127.0.0.1:9/api/generate", timeout=1)
        with self.assertRaises(TranslationError):
            t.translate("hello")


class BuildManagerTests(unittest.TestCase):
    def settings(self, **kw):
        s = dict(DEFAULTS, fast_local=False)  # bu testler Gemini/önbellek/yedek katmanlarını sınar
        s.update(kw)
        return s

    def test_requires_some_engine(self):
        with self.assertRaises(ValueError):
            build_manager(self.settings(gemini_key="", ollama_model="", offline=False), print)

    def test_gemini_result_is_cached_and_fallback_is_not(self):
        cache = PersistentCache(os.path.join(tempfile.mkdtemp(), "c.db"))
        s = self.settings(gemini_key="k", ollama_model="", offline=True)
        with mock.patch.object(GeminiTranslator, "translate", return_value="Merhaba") as g:
            m = build_manager(s, print, cache)
            self.assertEqual("Merhaba", m.translate("hello there friend"))
            self.assertEqual("Merhaba", m.translate("Hello there, friend"))  # hafızadan
            self.assertEqual(1, g.call_count)
        # Gemini çöküp yedek (Argos) çevirirse bu hafızaya YAZILMAZ
        with mock.patch.object(GeminiTranslator, "translate", side_effect=TranslationError(0, "ağ")), \
                mock.patch.object(ArgosTranslator, "translate", return_value="Zayıf çeviri"):
            m = build_manager(s, print, cache)
            self.assertEqual("Zayıf çeviri", m.translate("a brand new line"))
        self.assertIsNone(cache.get(f"{s['game']}|{s['gemini_model']}", "a brand new line"))

    def test_user_glossary_reaches_gemini_prompt_and_offline_text(self):
        s = self.settings(gemini_key="k", glossary="Ripperdoc=Siberdoktor", offline=True)
        m = build_manager(s, print)
        gemini = m._primary
        self.assertIn("Ripperdoc => Siberdoktor", gemini._glossary_hint)
        with mock.patch.object(ArgosTranslator, "translate", side_effect=lambda t: t) as a, \
                mock.patch.object(GeminiTranslator, "translate", side_effect=TranslationError(0, "ağ")):
            self.assertEqual("Siberdoktor is here", m.translate("Ripperdoc is here"))


if __name__ == "__main__":
    unittest.main()
