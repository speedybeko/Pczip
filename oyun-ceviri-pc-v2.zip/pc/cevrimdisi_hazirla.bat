@echo off
cd /d "%~dp0"
echo Cevrimdisi ceviri modeli kuruluyor (internet gerekir, bir kere)...
python -m pip install argostranslate
python oyunceviri_pc.py --cevrimdisi-hazirla
pause
