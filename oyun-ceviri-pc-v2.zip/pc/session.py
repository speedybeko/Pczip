"""Bir çeviri oturumu: yakalama + OCR + çeviri + hedefler. Konsol ve pencere arayüzü ortak kullanır."""
from __future__ import annotations

import threading
import time
from typing import Callable, Optional

from cache import PersistentCache
from capture import Ocr, ScreenGrabber, compute_region, frames_equal, mean_brightness, parse_region
from fast_local import FastGameTranslator
from glossary import BUILTIN_PHRASES, parse_glossary, prompt_hint
from pipeline import CompositeSink, Pipeline
from subtitle_core import SubtitleTracker, TranslatorManager, key as text_key
from translators import (
    ArgosTranslator, CachingTranslator, ChainTranslator, GeminiTranslator, OllamaTranslator, PhrasebookTranslator,
    ReplacingTranslator,
)
from tv_client import TOKEN_LENGTH, TvClient, normalize_token

FRAME_INTERVAL_S = 0.12  # varsayılan; ayarla "frame_ms" ile değişir

DEFAULTS = {
    "tv_token": "",
    "tv_ip": "",
    "tv_port": 8765,
    "tv_size": 28,
    "tv_bg": 70,
    "tv_color": "#FFFFFF",
    "tv_pos": 7,              # kutunun alt kenarı, ekranın altından % kaç yukarıda
    "tv_cover": 0,            # >0: sabit yükseklikli kutu (% ekran yüksekliği); oyunun kendi altyazısını kapatır
    "tv_width": 80,           # kapatma kutusunun genişliği (% ekran genişliği)
    "minimize_on_start": True,
    "gemini_key": "",
    "gemini_model": "gemini-3.5-flash-lite",
    "game": "Mortal Kombat 11",
    "glossary": "",
    "ollama_model": "",       # boş = Ollama kullanma (örn. gemma2:2b)
    "monitor": 1,
    "top": 72,
    "region": "",             # "x,y,genişlik,yükseklik"; doluysa 'top' yerine bu kullanılır
    "offline": True,          # Argos yedeği (kuruluysa)
    "fast_local": True,       # basit cümleleri kural motoruyla anında çevir (bilmediğini Gemini/Argos'a bırakır)
    "mode": "online",         # online: Gemini (+yedek) | hybrid: anında çevrimdışı taslak + Gemini | offline: yalnızca yerel
    "frame_ms": 120,          # kare aralığı; küçük = daha hızlı ama daha çok işlemci
    "stable_frames": 2,       # altyazının çevrilmesi için art arda görülmesi gereken kare sayısı
    "instant_chars": 14,      # tam cümle (. ? ! ile biten) bu kadar harften uzunsa ilk karede çevrilir; 0 = kapalı
    "clear_ms": 400,          # altyazı kaybolduktan kaç ms sonra TV'den silinsin
}

MODES = ("online", "hybrid", "offline")


def _offline_engine(settings: dict, notice: Callable[[str], None]) -> PhrasebookTranslator:
    """Hazır cümle sözlüğü + (varsa) kullanıcı sözlüğü + Argos. İlk ikisi model çalıştırmadan anında yanıt verir."""
    user_glossary = parse_glossary(settings.get("glossary", ""))
    argos = ReplacingTranslator(ArgosTranslator(on_notice=notice), user_glossary)
    return PhrasebookTranslator(argos, {**BUILTIN_PHRASES})


def make_fast(settings: dict):
    """Hızlı yerel motoru (kapalıysa None) verir. Özel sözlük terimi geçen satır Gemini'ye bırakılır."""
    if not settings.get("fast_local", True):
        return None
    # Gemini varsa kural motoru devreye girmez: kalite Gemini'de, kural motoru yalnızca çevrimdışı/anahtarsız kullanımda.
    if settings.get("mode", "online") != "offline" and str(settings.get("gemini_key", "")).strip():
        return None
    engine = FastGameTranslator()
    keys = [k.lower() for k in parse_glossary(settings.get("glossary", ""))]
    phrases = {text_key(k): v for k, v in BUILTIN_PHRASES.items()}  # oyun kalıpları (ör. "Finish him" -> "Bitir onu!")

    def fast(text: str):
        low = text.lower()
        if any(k in low for k in keys):
            return None
        return phrases.get(text_key(text)) or engine.translate_or_none(text)

    return fast


def build_manager(settings: dict, notice: Callable[[str], None], cache: Optional[PersistentCache] = None) -> TranslatorManager:
    mode = settings.get("mode", "online")
    user_glossary = parse_glossary(settings.get("glossary", ""))
    hint = prompt_hint(user_glossary)
    namespace = f"{settings['game']}|{settings['gemini_model']}"

    primary = None
    if mode != "offline" and settings["gemini_key"].strip():
        primary = GeminiTranslator(
            settings["gemini_key"].strip(), settings["gemini_model"], settings["game"], glossary_hint=hint
        )
        if cache is not None:
            primary = CachingTranslator(primary, cache, namespace)

    fallbacks = []
    if settings.get("ollama_model", "").strip():
        ollama = OllamaTranslator(settings["ollama_model"].strip(), settings["game"], hint)
        fallbacks.append(CachingTranslator(ollama, cache, "ollama|" + namespace) if cache is not None else ollama)
    if mode == "offline" or settings.get("offline", True):
        fallbacks.append(_offline_engine(settings, notice))
    fallback = ChainTranslator(fallbacks) if fallbacks else None

    if primary is None and fallback is None:
        raise ValueError("Çeviri motoru yok: Gemini anahtarı gir, Ollama modeli yaz ya da çevrimdışı yedeği aç.")
    manager = TranslatorManager(primary, fallback, clock=time.monotonic, on_notice=notice)
    manager.fast = make_fast(settings)
    return manager


def build_draft(settings: dict, notice: Callable[[str], None]) -> Optional[PhrasebookTranslator]:
    """Hibrit mod için anında çalışan çevrimdışı taslak motoru (diğer modlarda None)."""
    if settings.get("mode") == "hybrid":
        return _offline_engine(settings, notice)
    return None


def style_from_settings(settings: dict) -> dict:
    d = DEFAULTS
    return {
        "size": int(settings.get("tv_size", d["tv_size"])),
        "bg": int(settings.get("tv_bg", d["tv_bg"])),
        "shadow": True,
        "color": str(settings.get("tv_color", d["tv_color"])),
        "pos": int(settings.get("tv_pos", d["tv_pos"])),
        "cover": int(settings.get("tv_cover", d["tv_cover"])),
        "width": int(settings.get("tv_width", d["tv_width"])),
    }


def make_tv_client(settings: dict, on_state: Callable[[str, str], None]) -> Optional[TvClient]:
    token = normalize_token(settings["tv_token"])
    if len(token) != TOKEN_LENGTH:
        return None
    return TvClient(token, tv_ip=settings["tv_ip"], port=int(settings.get("tv_port", 8765)),
                    style=style_from_settings(settings), on_state=on_state)


class _CallbackSink:
    def __init__(self, on_show, on_clear):
        self._show, self._clear = on_show, on_clear

    def show(self, text: str) -> None:
        self._show(text)

    def clear(self) -> None:
        self._clear()


class Session:
    """start() ile ayrı thread'de çalışır, stop() ile temiz kapanır."""

    def __init__(
        self,
        settings: dict,
        on_log: Callable[[str], None] = print,
        on_original: Callable[[str], None] = lambda _t: None,
        on_translation: Callable[[str], None] = lambda _t: None,
        on_clear: Callable[[], None] = lambda: None,
        on_tv_state: Callable[[str, str], None] = lambda _s, _d: None,
    ):
        self._s = dict(DEFAULTS, **settings)
        self._log, self._on_original, self._on_translation = on_log, on_original, on_translation
        self._on_clear, self._on_tv_state = on_clear, on_tv_state
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._client: Optional[TvClient] = None

    def update_style(self, settings: dict) -> None:
        """Oturum çalışırken TV görünümünü canlı güncelle."""
        client = self._client
        if client is not None:
            client.set_style(style_from_settings(settings))

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="oturum", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=8)

    def join(self) -> None:
        while self.running:
            self._thread.join(timeout=0.5)  # type: ignore[union-attr]  # Ctrl+C'ye açık kalsın

    # -- iç --
    def _run(self) -> None:
        s = self._s
        grabber = pipeline = client = None
        try:
            grabber = ScreenGrabber(int(s["monitor"]))  # mss thread'e bağlı: burada oluşturulur
            explicit = parse_region(s["region"]) if str(s["region"]).strip() else None
            region = compute_region(grabber.monitor, int(s["top"]), explicit)
            self._log(f"Okunan bölge: {region.width}x{region.height} (sol={region.left}, üst={region.top})")
            self._log("OCR motoru yükleniyor...")
            ocr = Ocr()
            notice = lambda m: self._log(f"! {m}")  # noqa: E731
            manager = build_manager(s, notice, PersistentCache())
            draft_engine = build_draft(s, notice)
            if s.get("mode") != "online" or s.get("offline", True):
                threading.Thread(target=self._warm_up, args=(draft_engine, manager), name="isinma", daemon=True).start()

            client = make_tv_client(s, self._tv_state)
            self._client = client
            sinks = [_CallbackSink(self._on_translation, self._on_clear)]
            if client is not None:
                client.start()
                sinks.append(client)
            elif str(s["tv_token"]).strip():
                self._log("! TV kodu 8 harf/rakam olmalı; TV'ye gönderilmeyecek.")
            sink = CompositeSink(sinks, on_error=lambda x, e: self._log(f"! hedef hatası: {e}"))

            pipeline = Pipeline(
                grab=lambda: grabber.grab(region), ocr=ocr.read, manager=manager, sink=sink,
                clock_ms=lambda: int(time.monotonic() * 1000), same_frame=frames_equal,
                on_notice=lambda m: self._log(f"! {m}"), on_ocr=self._on_original,
                tracker=SubtitleTracker(int(s["stable_frames"]), int(s["clear_ms"]), int(s.get("instant_chars", 0))),
                draft=self._draft_fn(draft_engine, manager),
                on_timing=lambda kind, ms: self._log(f"⏱ {kind}: {ms} ms"),
            )
            self._log("Çalışıyor. Xbox uygulamasında oyunu aç.")
            black = 0
            last_black_check = 0.0
            frame_s = max(0.03, int(s["frame_ms"]) / 1000.0)
            while not self._stop.is_set():
                started = time.monotonic()
                if started - last_black_check > 1:
                    last_black_check = started
                    black = black + 1 if mean_brightness(grabber.grab(region)) < 1.5 else 0
                    if black == 30:
                        self._log("! Seçili alan 30 sn'dir simsiyah. Xbox penceresi bu alanda ve küçültülmemiş mi?")
                pipeline.step()
                self._stop.wait(max(0.0, frame_s - (time.monotonic() - started)))
        except Exception as e:  # noqa: BLE001 - kullanıcıya göster, çökme
            self._log(f"! Hata: {e}")
        finally:
            if pipeline is not None:
                pipeline.close()
            self._client = None
            if client is not None:
                client.stop()
            if grabber is not None:
                grabber.close()
            self._log("Durdu.")

    @staticmethod
    def _draft_fn(draft_engine, manager):
        """Hibrit mod taslağı: önce hızlı yerel motor, bilmiyorsa çevrimdışı model."""
        if draft_engine is None:
            return None
        fast = manager.fast

        def draft(text: str):
            if fast is not None:
                hit = fast(text)
                if hit:
                    return hit
            return draft_engine.translate(text)

        return draft

    def _warm_up(self, draft_engine, manager) -> None:
        """Çevrimdışı modeli arka planda yükler; ilk altyazıda bekleme olmasın."""
        try:
            (draft_engine or manager).warm_up()
            self._log("Çevrimdışı model hazır.")
        except Exception as e:  # noqa: BLE001 - kurulu değilse online çalışmaya devam
            self._log(f"! Çevrimdışı model hazırlanamadı: {e}")

    def _tv_state(self, state: str, detail: str) -> None:
        self._on_tv_state(state, detail)
        if detail:
            self._log(f"[TV] {detail}")
