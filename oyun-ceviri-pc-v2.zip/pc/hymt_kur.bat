@echo off
chcp 65001 >nul
cd /d %~dp0
echo HY-MT modeli duzgun sablonla olusturuluyor...
ollama pull hf.co/tencent/HY-MT1.5-1.8B-GGUF
ollama create hy-mt-tr -f Modelfile
echo.
echo Bitti. PC programinda Ollama modeli kutusuna su adi yaz: hy-mt-tr
pause
