"""Hızlı yerel çeviri motoru: kural tabanlı İngilizce -> Türkçe (kısa oyun altyazıları için).

core/FastGameTranslator.kt dosyasının Python karşılığıdır (aynı sözlük, aynı kurallar).
Emin olmadığı cümlede (bilinmeyen kelime vb.) None döner; böylece yarı İngilizce bozuk çıktı yerine
Gemini / Ollama / Argos devreye girer. Yalnızca standart kütüphane kullanır.
"""
from __future__ import annotations

import re
import threading
from collections import OrderedDict
from typing import Dict, List, Optional, Set, Tuple

from fast_local_data import IRREGULAR_PAST, NOUN_ADJ, PHRASAL_VERBS, PHRASES, QUESTION_WORDS, VERBS

VOWELS = "aeıioöuü"
BACK = "aıou"
HARD = "fstkçşhp"

# kişiler
P1S, P2S, P3S, P1P, P2P, P3P = "1s", "2s", "3s", "1p", "2p", "3p"
# zamanlar
PRESENT, PAST_CONT, PAST, FUTURE, AORIST, IMPERATIVE, CAN, MUST = (
    "present", "past_cont", "past", "future", "aorist", "imperative", "can", "must")
# haller
NONE, ACC, DAT, ABL = "NONE", "ACC", "DAT", "ABL"

TIME_ADVERBS = {"now", "today", "tonight", "tomorrow", "yesterday", "soon", "already", "again", "always"}
ADJECTIVE_PARTICIPLES = {"locked", "closed", "broken"}
DITRANSITIVE_ROOTS = {"ver", "anlat", "gönder", "getir"}
ADVERB_CASE_EXEMPT = {"burada", "orada", "şimdi", "buraya", "oraya"}
OBJECT_PRONOUNS = ("me", "you", "him", "her", "it", "us", "them")
POSSESSIVES = ("my", "your", "his", "her", "our", "their")
PREPOSITIONS = ("in", "on", "under", "for", "with", "without", "from", "to", "about", "behind")
AUX_STARTERS = ("do", "does", "did", "am", "is", "are", "was", "were", "can", "will", "have", "has")

_SPEAKER = re.compile(r"^([A-Z][A-Za-z]{1,14}(?: [A-Z][A-Za-z]{1,14})?:)\s*(.+)$")
_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")
_PHRASAL = [(re.compile(rf"\b{re.escape(k)}\b"), v)
            for k, v in sorted(PHRASAL_VERBS.items(), key=lambda kv: -len(kv[0]))]
_PHRASE = [(re.compile(rf"\b{re.escape(k)}\b"), "[" + v.replace(" ", "=") + "]")
           for k, v in sorted(PHRASES.items(), key=lambda kv: -len(kv[0])) if " " in k]


def _last_vowel(word: str, default: str = "e") -> str:
    for ch in reversed(word):
        if ch in VOWELS:
            return ch
    return default


def _four_way(v: str) -> str:
    return {"a": "ı", "ı": "ı", "e": "i", "i": "i", "o": "u", "u": "u", "ö": "ü", "ü": "ü"}.get(v, "i")


def _capitalize(text: str) -> str:
    if not text:
        return text
    first = text[0]
    up = "İ" if first == "i" else "I" if first == "ı" else first.upper()
    return up + text[1:]


def _ends_with_vowel(w: str) -> bool:
    return bool(w) and w[-1] in VOWELS


def _clean_ocr_noise(text: str) -> str:
    t = re.sub(r"[♪♫#*~_|<>\[\]]", "", text)
    t = re.sub(r"\b1\b", "I", t)
    t = re.sub(r"\bl'm\b", "I'm", t)
    t = re.sub(r"\bl\b", "I", t)
    t = re.sub(r"\.{2,}", ".", t)
    return re.sub(r"\s+", " ", t).strip()


_CONTRACTIONS = [
    (r"\bi'm\b", "i am"), (r"\bim\b", "i am"),
    (r"\byou're\b", "you are"), (r"\bwe're\b", "we are"), (r"\bthey're\b", "they are"),
    (r"\bhe's\b", "he is"), (r"\bshe's\b", "she is"), (r"\bit's\b", "it is"),
    (r"\bdon't\b", "do not"), (r"\bdont\b", "do not"),
    (r"\bdoesn't\b", "does not"), (r"\bdidn't\b", "did not"), (r"\bdidnt\b", "did not"),
    (r"\bcan't\b", "can not"), (r"\bcant\b", "can not"),
    (r"\bwon't\b", "will not"), (r"\bisn't\b", "is not"), (r"\baren't\b", "are not"),
    (r"\bi'll\b", "i will"), (r"\byou'll\b", "you will"), (r"\bwe'll\b", "we will"),
    (r"\blet's\b", "let us"), (r"\blets\b", "let us"),
    (r"\bwhat's\b", "what is"), (r"\bwhere's\b", "where is"), (r"\bwho's\b", "who is"),
    (r"\bgonna\b", "will"), (r"\bwanna\b", "want"), (r"\bgotta\b", "must"),
]
_CONTRACTIONS = [(re.compile(p), r) for p, r in _CONTRACTIONS]


def _expand_contractions(text: str) -> str:
    t = text.replace("’", "'")
    for pat, rep in _CONTRACTIONS:
        t = pat.sub(rep, t)
    return t


# ---------- Türkçe ek yardımcıları ----------

def _soften_noun(noun: str) -> str:
    if len(noun) < 3:
        return noun
    last = noun[-1]
    if last == "p":
        return noun[:-1] + "b"
    if last == "ç":
        return noun[:-1] + "c"
    if last == "k":
        return noun[:-1] + "ğ"
    return noun


_SOFTENABLE_ET = {"git", "et", "kaybet", "hisset", "affet", "seyret", "terk et", "yardım et", "takip et",
                  "nefret et", "yok et", "tamir et", "kontrol et", "hareket et"}


def _soften_verb(root: str) -> str:
    if root in _SOFTENABLE_ET or root.endswith(" et"):
        return root[:-1] + "d"
    return root


def _object_pronoun(p: str, case: str) -> str:
    if case == DAT:
        return {"me": "bana", "you": "sana", "him": "ona", "her": "ona", "it": "ona",
                "us": "bize", "them": "onlara"}.get(p, "ona")
    if case == ABL:
        return {"me": "benden", "you": "senden", "him": "ondan", "her": "ondan", "it": "ondan",
                "us": "bizden", "them": "onlardan"}.get(p, "ondan")
    return {"me": "beni", "you": "seni", "him": "onu", "her": "onu", "it": "onu",
            "us": "bizi", "them": "onları"}.get(p, "onu")


def _all_pronoun(p: str, case: str) -> str:
    if case == DAT:
        return "hepimize" if p == "us" else "hepsine"
    if case == ABL:
        return "hepimizden" if p == "us" else "hepsinden"
    return "hepimizi" if p == "us" else "hepsini"


def _possessive(noun: str, owner: str) -> str:
    soft = _soften_noun(noun)
    lv = _last_vowel(soft)
    v = _four_way(lv)
    ev = _ends_with_vowel(soft)
    if owner == "my":
        return soft + "m" if ev else f"{soft}{v}m"
    if owner == "your":
        return soft + "n" if ev else f"{soft}{v}n"
    if owner in ("his", "her"):
        return f"{soft}s{v}" if ev else f"{soft}{v}"
    if owner == "our":
        return f"{soft}m{v}z" if ev else f"{soft}{v}m{v}z"
    if owner == "their":
        return noun + ("ları" if lv in BACK else "leri")
    return noun


def _case(word: str, case: str, possessed: bool) -> str:
    if case == NONE or word in ADVERB_CASE_EXEMPT:
        return word
    if word in ("bu", "şu"):
        return word + {ACC: "nu", DAT: "na"}.get(case, "ndan")
    soft = word if possessed else _soften_noun(word)
    lv = _last_vowel(soft)
    back = lv in BACK
    buf = "y" if _ends_with_vowel(soft) else ""
    if case == ACC:
        return f"{soft}{buf}{_four_way(lv)}"
    if case == DAT:
        return f"{soft}{buf}{'a' if back else 'e'}"
    if case == ABL:
        d = "t" if word[-1] in HARD else "d"
        return f"{word}{d}{'an' if back else 'en'}"
    return word


def _copula(word: str, person: str) -> str:
    if person not in (P1S, P2S, P1P):
        return ""
    v = _four_way(_last_vowel(word))
    y = "y" if _ends_with_vowel(word) else ""
    if person == P1S:
        return f"{y}{v}m"
    if person == P2S:
        return f"s{v}n"
    return f"{y}{v}z"


def _nominal_question(word: str, person: str) -> str:
    v = _four_way(_last_vowel(word))
    suffix = {P1S: f"m{v}y{v}m", P2S: f"m{v}s{v}n", P1P: f"m{v}y{v}z"}.get(person, f"m{v}")
    return f"{word} {suffix}"


def _conjugate(root: str, tense: str, person: str, neg: bool, question: bool) -> str:
    lv = _last_vowel(root)
    back = lv in BACK
    v4 = _four_way(lv)

    if tense == IMPERATIVE and not question:
        if person == P1P:
            soft = _soften_verb(root)
            if neg:
                return root + ("mayalım" if back else "meyelim")
            return soft + ("alım" if back else "elim")
        return root + ("ma" if back else "me") if neg else root

    if tense in (PRESENT, AORIST, PAST_CONT):
        if neg:
            stem = root + "m"
        else:
            stem = root[:-1] if root[-1] in "ae" else _soften_verb(root)
        iyor_v = v4 if neg else _four_way(_last_vowel(stem, lv))
        core = f"{stem}{iyor_v}yor" if stem[-1] not in VOWELS else f"{stem}yor"
        if tense == PAST_CONT:
            ps = {P1S: "dum", P2S: "dun", P1P: "duk", P3P: "lardı"}.get(person, "du")
            if question:
                return f"{core} mu" + {P1S: "ydum", P2S: "ydun", P1P: "yduk"}.get(person, "ydu")
            return core + ps
        ps = {P1S: "um", P2S: "sun", P3S: "", P1P: "uz", P2P: "sunuz", P3P: "lar"}[person]
        if question:
            q = {P1S: "muyum", P2S: "musun", P1P: "muyuz"}.get(person, "mu")
            return f"{core} {q}"
        return core + ps

    if tense == PAST:
        stem = root + ("ma" if back else "me") if neg else root
        sv = ("ı" if back else "i") if neg else v4
        dt = "t" if stem[-1] in HARD else "d"
        ps = {P1S: "m", P2S: "n", P1P: "k", P3P: "lar" if back else "ler"}.get(person, "")
        conj = f"{stem}{dt}{sv}{ps}"
        return f"{conj} m{sv}" if question else conj

    if tense == FUTURE:
        stem = root + ("ma" if back else "me") if neg else _soften_verb(root)
        by = "y" if stem[-1] in VOWELS else ""
        acak = "acak" if back else "ecek"
        if person == P1S:
            core = f"{stem}{by}{acak[:-1]}{'ğım' if back else 'ğim'}"
        elif person == P2S:
            core = f"{stem}{by}{acak}{'sın' if back else 'sin'}"
        elif person == P1P:
            core = f"{stem}{by}{acak[:-1]}{'ğız' if back else 'ğiz'}"
        else:
            core = f"{stem}{by}{acak}"
        return f"{stem}{by}{acak} m{'ı' if back else 'i'}" if question else core

    if tense == CAN:
        soft = _soften_verb(root)
        by = "y" if soft[-1] in VOWELS else ""
        ae = "a" if back else "e"
        ii = "ı" if back else "i"
        if neg:
            nb = f"{soft}{by}{ae}m{ae}"
            return nb + {P1S: "m", P2S: f"zs{ii}n", P1P: f"y{ii}z"}.get(person, "z")
        pb = f"{soft}{by}{ae}bilir"
        if question:
            return pb + {P1S: "miyim", P2S: "misin", P1P: "miyiz"}.get(person, "mi")
        return pb + {P1S: "im", P2S: "sin", P1P: "iz"}.get(person, "")

    if tense == MUST:
        neg_part = ("ma" if back else "me") if neg else ""
        mali = "malı" if back else "meli"
        ps = {P1S: "yım" if back else "yim", P2S: "sın" if back else "sin",
              P1P: "yız" if back else "yiz"}.get(person, "")
        return f"{root}{neg_part}{mali}{ps}"

    return root


# ---------- sözlük arama ----------

def _resolve_noun(token: str, proper: Set[str]) -> Optional[str]:
    if token.startswith("[") and token.endswith("]"):
        return token[1:-1].replace("=", " ")
    hit = NOUN_ADJ.get(token)
    if hit is not None:
        return hit
    hit = QUESTION_WORDS.get(token)
    if hit is not None:
        return hit
    if token.endswith("ies") and len(token) > 4:
        root = NOUN_ADJ.get(token[:-3] + "y")
        if root is not None:
            return root + ("lar" if any(c in BACK for c in root) else "ler")
    if token.endswith("s") and len(token) > 3:
        root = NOUN_ADJ.get(token[:-1])
        if root is not None:
            return root + ("lar" if any(c in BACK for c in root) else "ler")
    if token in proper or (token and token.isdigit()):
        return _capitalize(token)
    return None


def _extract_verb(token: str, current: str) -> Optional[Tuple[Tuple[str, str], str]]:
    key = IRREGULAR_PAST.get(token)
    if key is not None and key in VERBS:
        return VERBS[key], PAST
    if token in VERBS:
        return VERBS[token], current
    if token.endswith("ing") and len(token) > 4:
        base = token[:-3]
        cands = [base, base + "e", base[:-1] if len(base) > 2 and base[-1] == base[-2] else ""]
        for c in cands:
            if c in VERBS:
                return VERBS[c], PRESENT
    if token.endswith("ed") and len(token) > 3:
        base = token[:-2]
        cands = [base, token[:-1], base[:-1] + "y" if base.endswith("i") else ""]
        for c in cands:
            if c in VERBS:
                return VERBS[c], PAST
    if token.endswith("s") and len(token) > 3:
        for c in (token[:-1], token[:-2] if token.endswith("es") else token):
            if c in VERBS:
                return VERBS[c], PRESENT
    return None


def _resolve_preposition(prep: str, target: str, proper: Set[str]) -> Optional[str]:
    if target in ("me", "you", "him", "her", "us", "them"):
        if prep == "with":
            return {"me": "benimle", "you": "seninle", "us": "bizimle"}.get(target, "onunla")
        if prep == "for":
            return {"me": "benim için", "you": "senin için", "us": "bizim için"}.get(target, "onun için")
        if prep == "to":
            return _object_pronoun(target, DAT)
        if prep == "from":
            return _object_pronoun(target, ABL)
        return None
    tr = _resolve_noun(target, proper)
    if tr is None:
        return None
    if tr in ("bu", "şu"):
        gen = tr + "nun"
        if prep == "for":
            return f"{gen} için"
        if prep == "about":
            return f"{gen} hakkında"
        if prep == "with":
            return f"{tr}nunla"
        if prep == "from":
            return _case(tr, ABL, False)
        if prep == "to":
            return _case(tr, DAT, False)
        if prep in ("in", "on"):
            return f"{tr}nda"
        return None
    lv = _last_vowel(tr)
    d_or_t = "t" if tr[-1] in HARD else "d"
    a_or_e = "a" if lv in BACK else "e"
    if prep in ("in", "on"):
        return f"{tr}{d_or_t}{a_or_e}"
    if prep == "from":
        return _case(tr, ABL, False)
    if prep == "to":
        return _case(tr, DAT, False)
    return {"with": f"{tr} ile", "without": f"{tr} olmadan", "for": f"{tr} için",
            "under": f"{tr} altında", "behind": f"{tr} arkasında", "about": f"{tr} hakkında"}.get(prep, tr)


# ---------- tek cümle ----------

def _translate_sentence(sentence: str) -> Optional[str]:
    is_question_text = sentence.strip().endswith("?")
    end_punct = sentence[-1] if sentence and sentence[-1] in ".!?" else ""

    raw_words = re.split(r"\s+", re.sub(r"[^A-Za-z0-9\s]", " ", sentence).strip())
    proper = {w.lower() for w in raw_words[1:] if w and w[0].isupper()}

    normalized = _expand_contractions(sentence.lower())
    normalized = re.sub(r"[^a-z0-9\s]", " ", normalized)
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if not normalized:
        return sentence

    exact = PHRASES.get(normalized)
    if exact is not None:
        return _capitalize(exact) + end_punct

    for pat, rep in _PHRASAL:
        normalized = pat.sub(rep, normalized)
    for pat, rep in _PHRASE:
        normalized = pat.sub(rep, normalized)

    tokens = [t for t in normalized.split(" ") if t.strip()]
    if not tokens:
        return None
    phrase_used = any(t.startswith("[") for t in tokens)

    person = P2S
    has_subject = False
    tense = IMPERATIVE
    negative = False
    question = is_question_text
    q_tr: Optional[str] = None
    q_en: Optional[str] = None
    aux_seen = False
    past_aux = False
    dative_given = False
    adverbs: List[str] = []

    if tokens[0] in QUESTION_WORDS:
        q_en = tokens.pop(0)
        q_tr = QUESTION_WORDS[q_en]
        question = True

    neg_imperative = len(tokens) > 1 and tokens[0] in ("do", "does") and tokens[1] == "not" and not is_question_text
    if neg_imperative:
        tokens.pop(0)
    elif tokens and tokens[0] in AUX_STARTERS:
        question = True
        aux_seen = True
        aux = tokens.pop(0)
        if aux == "did":
            tense = PAST
        elif aux in ("was", "were"):
            tense, past_aux = PAST, True
        elif aux == "will":
            tense = FUTURE
        elif aux == "can":
            tense = CAN
        elif aux in ("am", "is", "are"):
            tense = PRESENT
        elif aux in ("do", "does"):
            tense = AORIST

    verb: Optional[Tuple[str, str]] = None  # (kök, hal)
    subject: List[str] = []
    objects: List[str] = []

    i = 0
    n = len(tokens)
    while i < n:
        token = tokens[i]

        if token in ("the", "a", "an", "please"):
            if token == "please":
                subject.append("lütfen")
            i += 1
            continue

        if token in ("not", "never"):
            negative = True
            if token == "never":
                subject.append("asla")
            i += 1
            continue
        if token == "will":
            tense = FUTURE; i += 1; continue
        if token == "can":
            tense = CAN; i += 1; continue
        if token in ("must", "should"):
            tense = MUST; i += 1; continue
        if token in ("am", "is", "are"):
            tense = PRESENT; i += 1; continue
        if token in ("was", "were"):
            tense, past_aux = PAST, True; i += 1; continue
        if token == "had":
            tense = PAST; i += 1; continue
        if token in ("did", "do", "does") and not aux_seen and i + 1 < n and tokens[i + 1] == "not":
            tense = PAST if token == "did" else AORIST
            i += 1
            continue
        if token == "let" and i + 1 < n and tokens[i + 1] == "us":
            person, has_subject = P1P, True
            subject.append("hadi")
            i += 2
            continue

        if verb is None:
            detected = None if token in ADJECTIVE_PARTICIPLES else _extract_verb(token, tense)
            if detected is not None:
                verb = detected[0]
                tense = PAST_CONT if (past_aux and detected[1] == PRESENT) else detected[1]
                i += 1
                continue
            pron = {"i": P1S, "you": P2S, "he": P3S, "she": P3S, "it": P3S, "we": P1P, "they": P3P}.get(token)
            if pron is not None:
                person, has_subject = pron, True
                i += 1
                continue

        if token in POSSESSIVES and i + 1 < n:
            nxt = _resolve_noun(tokens[i + 1], proper)
            if nxt is None:
                return None
            possessed = _possessive(nxt, token)
            if verb is None:
                person, has_subject = P3S, True
                subject.append(possessed)
            else:
                pc = ACC if (dative_given and verb[1] == DAT) else verb[1]
                objects.append(_case(possessed, pc, True))
            i += 2
            continue

        if token in PREPOSITIONS:
            nxt_idx = i + 2 if (i + 1 < n and tokens[i + 1] in ("the", "a", "an")) else i + 1
            if nxt_idx < n:
                combined = _resolve_preposition(token, tokens[nxt_idx], proper)
                if combined is None:
                    return None
                objects.append(combined)
                i = nxt_idx + 1
                continue

        if verb is not None and token in OBJECT_PRONOUNS:
            indirect = verb[0] in DITRANSITIVE_ROOTS and not dative_given and i + 1 < n
            oc = DAT if indirect else verb[1]
            if indirect:
                dative_given = True
            if i + 1 < n and tokens[i + 1] == "all" and token in ("them", "us"):
                objects.append(_all_pronoun(token, oc))
                i += 2
                continue
            objects.append(_object_pronoun(token, oc))
            i += 1
            continue

        resolved = _resolve_noun(token, proper)
        if resolved is None:
            return None
        if token in TIME_ADVERBS:
            adverbs.append(resolved)
        elif verb is None:
            if not has_subject:
                has_subject = True
                person = P3S
            subject.append(resolved)
        else:
            if token in ("here", "there") and verb[1] == DAT:
                resolved = "buraya" if token == "here" else "oraya"
            last_word = i == n - 1
            oc = ACC if (dative_given and verb[1] == DAT) else verb[1]
            objects.append(_case(resolved, oc, False) if last_word else resolved)
        i += 1

    out: List[str] = adverbs + subject + objects

    if q_tr is not None:
        where_to = q_en == "where" and verb is not None and verb[1] == DAT
        out.append("nereye" if where_to else q_tr)

    if verb is not None:
        if tense == IMPERATIVE and has_subject:
            tense = PRESENT
        out.append(_conjugate(verb[0], tense, person, negative, question and q_tr is None))
    else:
        if negative:
            out.append("değil mi" if (question and q_tr is None) else "değil" + _copula("değil", person))
        elif question and q_tr is None and not phrase_used and out:
            out.append(_nominal_question(out.pop(), person))
        elif (not question and q_tr is None and has_subject and subject and tense == PRESENT
              and person in (P1S, P2S, P1P)):
            last = out.pop()
            out.append(last + _copula(last, person))

    result = re.sub(r"\s+", " ", " ".join(out)).strip()
    if not result:
        return None
    return _capitalize(result) + end_punct


class FastGameTranslator:
    """translate_or_none(): emin olduğu cümleyi çevirir, değilse None döner. İş parçacığı güvenlidir."""

    def __init__(self, cache_size: int = 1000):
        self._cache: "OrderedDict[str, str]" = OrderedDict()
        self._size = cache_size
        self._lock = threading.Lock()

    def translate_or_none(self, raw: str) -> Optional[str]:
        cleaned = _clean_ocr_noise(raw)
        if not cleaned:
            return None
        with self._lock:
            hit = self._cache.get(cleaned)
            if hit is not None:
                self._cache.move_to_end(cleaned)
                return hit

        speaker, body = "", cleaned
        m = _SPEAKER.match(cleaned)
        if m:
            speaker, body = m.group(1) + " ", m.group(2)

        parts: List[str] = []
        for s in _SENTENCE_SPLIT.split(body):
            t = _translate_sentence(s)
            if t is None:
                return None
            parts.append(t)
        final = speaker + " ".join(parts)
        with self._lock:
            self._cache[cleaned] = final
            if len(self._cache) > self._size:
                self._cache.popitem(last=False)
        return final
