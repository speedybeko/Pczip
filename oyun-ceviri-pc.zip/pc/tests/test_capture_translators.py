import os
import tempfile
import unittest

import numpy as np

from capture import Ocr, compute_region, frames_equal, mean_brightness, parse_region, write_png
from translators import GeminiTranslator


class RegionTests(unittest.TestCase):
    MON = {"left": 0, "top": 0, "width": 1920, "height": 1080}

    def test_bottom_28_percent(self):
        r = compute_region(self.MON, 72)
        self.assertEqual((0, 777, 1920, 303), (r.left, r.top, r.width, r.height))

    def test_second_monitor_offset(self):
        r = compute_region({"left": 1920, "top": 0, "width": 1920, "height": 1080}, 80)
        self.assertEqual(1920, r.left)
        self.assertEqual(864, r.top)

    def test_explicit_region_wins(self):
        r = compute_region(self.MON, 72, (100, 200, 800, 100))
        self.assertEqual((100, 200, 800, 100), (r.left, r.top, r.width, r.height))
        self.assertEqual((1, 2, 3, 4), parse_region("1, 2,3 ,4"))
        with self.assertRaises(ValueError):
            parse_region("1,2,3")

    def test_percent_is_clamped(self):
        self.assertEqual(1026, compute_region(self.MON, 200).top)  # %95


class ImageTests(unittest.TestCase):
    def test_brightness_and_equality(self):
        black = np.zeros((40, 80, 3), dtype=np.uint8)
        white = np.full((40, 80, 3), 255, dtype=np.uint8)
        self.assertLess(mean_brightness(black), 1)
        self.assertGreater(mean_brightness(white), 250)
        self.assertTrue(frames_equal(black, black.copy()))
        self.assertFalse(frames_equal(black, white))
        self.assertFalse(frames_equal(None, black))

    def test_png_roundtrip_with_pillow(self):
        from PIL import Image

        img = np.zeros((10, 20, 3), dtype=np.uint8)
        img[:, :, 2] = 200  # BGR: kırmızı kanal
        path = os.path.join(tempfile.mkdtemp(), "t.png")
        write_png(path, img)
        out = Image.open(path).convert("RGB")
        self.assertEqual((20, 10), out.size)
        self.assertEqual((200, 0, 0), out.getpixel((5, 5)))


class OcrJoinTests(unittest.TestCase):
    def box(self, x, y):
        return [[x, y], [x + 50, y], [x + 50, y + 10], [x, y + 10]]

    def test_orders_top_to_bottom_left_to_right_and_drops_low_scores(self):
        result = [
            [self.box(0, 40), "second line", 0.9],
            [self.box(60, 0), "world", 0.9],
            [self.box(0, 0), "Hello", 0.95],
            [self.box(0, 80), "noise", 0.2],
        ]
        self.assertEqual("Hello world second line", Ocr.join_lines(result))
        self.assertEqual("", Ocr.join_lines(None))


class GeminiParseTests(unittest.TestCase):
    def test_parse(self):
        ok = '{"candidates":[{"content":{"parts":[{"text":" \\"Merhaba\\" "}]}}]}'
        self.assertEqual("Merhaba", GeminiTranslator.parse(ok))
        self.assertIsNone(GeminiTranslator.parse('{"candidates":[]}'))
        self.assertIsNone(GeminiTranslator.parse("bozuk"))

    def test_body_contains_context_and_game(self):
        g = GeminiTranslator("k", "m", "Mortal Kombat 11")
        g._history.extend(["one", "two"])
        body = g._build_body("three")
        prompt = body["contents"][0]["parts"][0]["text"]
        self.assertIn("Game: Mortal Kombat 11", prompt)
        self.assertIn("- one", prompt)
        self.assertTrue(prompt.endswith("three"))
        self.assertIn("EVERY word", body["systemInstruction"]["parts"][0]["text"])


if __name__ == "__main__":
    unittest.main()
