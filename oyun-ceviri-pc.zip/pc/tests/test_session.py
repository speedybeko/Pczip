import os
import tempfile
import time
import unittest
from unittest import mock

import numpy as np

import session as session_mod
from cache import PersistentCache as RealCache
from session import DEFAULTS, Session
from tests.fake_tv import FakeTv
from translators import ArgosTranslator
from tv_client import msg_clear, msg_subtitle

L1 = "You're talking nonsense, man. You raised a fine daughter."


class FakeGrabber:
    """Her grab()'da bir sonraki 'kareyi' verir; kare = OCR'ın okuyacağı metin."""
    script = []
    pos = 0
    monitor = {"left": 0, "top": 0, "width": 1920, "height": 1080}

    def __init__(self, monitor_index=1):
        pass

    def grab(self, region):
        i = min(FakeGrabber.pos, len(FakeGrabber.script) - 1)
        FakeGrabber.pos += 1
        img = np.full((20, 40, 3), 10 + 5 * i, dtype=np.uint8)  # her kare farklı: OCR atlanmasın
        img[0, 0, 0] = i
        return img

    def close(self):
        pass


class FakeOcr:
    def read(self, image):
        i = int(image[0, 0, 0])
        return FakeGrabber.script[min(i, len(FakeGrabber.script) - 1)]


def wait_for(cond, timeout=10.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


class SessionEndToEnd(unittest.TestCase):
    def test_subtitle_flows_to_tv_and_clears(self):
        tv = FakeTv("ABCD2345")
        self.addCleanup(tv.close)
        FakeGrabber.script = [L1] * 6 + [""] * 60
        FakeGrabber.pos = 0
        logs, shown = [], []
        settings = dict(DEFAULTS, tv_token="abcd-2345", tv_ip="127.0.0.1", tv_port=tv.port,
                        gemini_key="", offline=True, region="0,0,100,40")
        with mock.patch.object(session_mod, "ScreenGrabber", FakeGrabber), \
                mock.patch.object(session_mod, "Ocr", FakeOcr), \
                mock.patch.object(session_mod, "FRAME_INTERVAL_S", 0.02), \
                mock.patch.object(session_mod, "PersistentCache", lambda: RealCache(
                    os.path.join(tempfile.mkdtemp(), "c.db"))), \
                mock.patch.object(ArgosTranslator, "translate", side_effect=lambda t: "TR " + t):
            sess = Session(settings, on_log=logs.append, on_translation=shown.append)
            sess.start()
            self.addCleanup(sess.stop)
            self.assertTrue(wait_for(lambda: msg_subtitle("TR " + L1) in tv.received), logs)
            self.assertTrue(wait_for(lambda: msg_clear() in tv.received), logs)  # ~500 ms boşluk sonrası
            sess.stop()
        self.assertFalse(sess.running)
        self.assertIn("TR " + L1, shown)
        self.assertEqual(1, tv.received.count(msg_subtitle("TR " + L1)))  # tekrar tekrar gönderilmedi


if __name__ == "__main__":
    unittest.main()
