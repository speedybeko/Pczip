import unittest

from subtitle_core import (
    CLEAR, Show, SubtitleTracker, TranslationError, TranslatorManager,
    edit_distance, key, looks_like_subtitle, normalize, similar,
)


class TextTests(unittest.TestCase):
    def test_normalize(self):
        self.assertEqual("You're talking nonsense, man.", normalize("  You're   talking\nnonsense,\t man.  "))

    def test_looks_like_subtitle(self):
        self.assertTrue(looks_like_subtitle("Thank you, both of you."))
        self.assertFalse(looks_like_subtitle(""))
        self.assertFalse(looks_like_subtitle("ab"))
        self.assertFalse(looks_like_subtitle("|| -- // 12 34 ..."))

    def test_key(self):
        self.assertEqual("worrynot", key("Worry, NOT!"))

    def test_similar_jitter_vs_different(self):
        a = key("They're en route. Kitana and I will see that they arrive as planned.")
        b = key("They're en route. Kitana and I will see that they arrlve as planned.")
        self.assertTrue(similar(a, b))
        self.assertFalse(similar(key("Thank you, both of you."), key("Understood, Jackson Briggs.")))
        self.assertFalse(similar("worrynot", "wearenot"))

    def test_edit_distance(self):
        self.assertEqual(3, edit_distance("kitten", "sitting"))
        self.assertEqual(0, edit_distance("abc", "abc"))
        self.assertEqual(3, edit_distance("", "abc"))


L1 = "You're talking nonsense, man. You raised a fine daughter."
L2 = "Thank you, both of you."


class TrackerTests(unittest.TestCase):
    def setUp(self):
        self.t = SubtitleTracker(2, 500)

    def test_shows_after_two_stable_frames(self):
        self.assertIsNone(self.t.on_ocr(L1, 0))
        self.assertEqual(Show(L1), self.t.on_ocr(L1, 250))

    def test_single_frame_noise_ignored(self):
        self.assertIsNone(self.t.on_ocr("Garbage text here", 0))
        self.assertIsNone(self.t.on_ocr(L1, 250))
        self.assertEqual(Show(L1), self.t.on_ocr(L1, 500))

    def test_same_line_not_shown_twice(self):
        self.t.on_ocr(L1, 0)
        self.assertEqual(Show(L1), self.t.on_ocr(L1, 250))
        self.assertIsNone(self.t.on_ocr(L1, 500))

    def test_ocr_jitter_is_same_line(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        j = L1.replace("daughter", "daughler")
        self.assertIsNone(self.t.on_ocr(j, 500))
        self.assertIsNone(self.t.on_ocr(j, 750))

    def test_new_line_replaces_old(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        self.assertIsNone(self.t.on_ocr(L2, 500))
        self.assertEqual(Show(L2), self.t.on_ocr(L2, 750))

    def test_clear_only_after_delay(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        self.assertIsNone(self.t.on_ocr("", 500))
        self.assertIsNone(self.t.on_ocr("", 749))
        self.assertIs(CLEAR, self.t.on_ocr("", 1000))

    def test_brief_gap_does_not_flicker(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        self.assertIsNone(self.t.on_ocr("", 500))
        self.assertIsNone(self.t.on_ocr(L1, 750))
        self.assertIsNone(self.t.on_ocr("", 1000))
        self.assertIsNone(self.t.on_ocr(L1, 1250))

    def test_no_clear_when_nothing_shown_and_clear_once(self):
        self.assertIsNone(self.t.on_ocr("", 0))
        self.assertIsNone(self.t.on_ocr("", 600))
        self.t.on_ocr(L1, 1000)
        self.t.on_ocr(L1, 1250)
        self.t.on_ocr("", 1500)
        self.assertIs(CLEAR, self.t.on_ocr("", 2000))
        self.assertIsNone(self.t.on_ocr("", 2250))

    def test_same_line_again_after_clear(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        self.t.on_ocr("", 500)
        self.t.on_ocr("", 1000)
        self.assertIsNone(self.t.on_ocr(L1, 1250))
        self.assertEqual(Show(L1), self.t.on_ocr(L1, 1500))

    def test_reset(self):
        self.t.on_ocr(L1, 0)
        self.t.on_ocr(L1, 250)
        self.t.reset()
        self.assertIsNone(self.t.on_ocr(L1, 500))
        self.assertEqual(Show(L1), self.t.on_ocr(L1, 750))


class Fake:
    def __init__(self, name, failure=None):
        self.name, self.failure, self.calls, self.closed = name, failure, 0, False

    def translate(self, text):
        self.calls += 1
        err = self.failure() if self.failure else None
        if err:
            raise err
        return f"{self.name}:{text}"

    def close(self):
        self.closed = True


class ManagerTests(unittest.TestCase):
    def setUp(self):
        self.now = 0.0
        self.notices = []

    def mgr(self, primary, fallback):
        return TranslatorManager(primary, fallback, clock=lambda: self.now, on_notice=self.notices.append)

    def test_primary_then_fallback_when_none(self):
        self.assertEqual("g:hi", self.mgr(Fake("g"), Fake("o")).translate("hi"))
        self.assertEqual("o:hi", self.mgr(None, Fake("o")).translate("hi"))

    def test_network_error_falls_back_for_that_line_only(self):
        fail = [True]
        p = Fake("g", lambda: TranslationError(0, "ağ") if fail[0] else None)
        m = self.mgr(p, Fake("o"))
        self.assertEqual("o:a", m.translate("a"))
        fail[0] = False
        self.assertEqual("g:b", m.translate("b"))
        self.assertEqual([], self.notices)

    def test_rate_limit_pauses_primary(self):
        limited = [True]
        p = Fake("g", lambda: TranslationError(429, "limit") if limited[0] else None)
        m = self.mgr(p, Fake("o"))
        self.assertEqual("o:a", m.translate("a"))
        self.assertEqual(1, len(self.notices))
        limited[0] = False
        self.now = 30
        self.assertEqual("o:b", m.translate("b"))
        self.assertEqual(1, p.calls)
        self.now = 60.5
        self.assertEqual("g:c", m.translate("c"))

    def test_client_error_disables_primary(self):
        p = Fake("g", lambda: TranslationError(403, "anahtar"))
        m = self.mgr(p, Fake("o"))
        self.assertEqual("o:a", m.translate("a"))
        self.assertTrue(p.closed)
        self.assertEqual("o:b", m.translate("b"))
        self.assertEqual(1, p.calls)

    def test_no_fallback_raises(self):
        m = self.mgr(Fake("g", lambda: TranslationError(0, "ağ")), None)
        with self.assertRaises(TranslationError):
            m.translate("a")


if __name__ == "__main__":
    unittest.main()
