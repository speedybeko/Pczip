"""Ekran yakalama (mss) ve OCR (rapidocr) bağdaştırıcıları + bölge hesabı.

Ağır paketler (mss, numpy, rapidocr) yalnızca kullanılırken içe aktarılır; böylece
mantık kısmı bu paketler olmadan da test edilebilir.
"""
from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass
from typing import List, Optional, Tuple


def enable_dpi_awareness() -> None:
    """Windows %125/%150 ölçekte alan koordinatları ile gerçek piksellerin kaymaması için."""
    import sys

    if sys.platform != "win32":
        return
    import ctypes

    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:  # noqa: BLE001
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass


@dataclass(frozen=True)
class Region:
    left: int
    top: int
    width: int
    height: int


def compute_region(
    monitor: dict,
    top_percent: int = 72,
    explicit: Optional[Tuple[int, int, int, int]] = None,
) -> Region:
    """Okunacak alan: ya açık `x,y,w,h` ya da monitörün alt kısmı (üst kenar % olarak)."""
    if explicit is not None:
        x, y, w, h = explicit
        return Region(x, y, max(1, w), max(1, h))
    top_percent = max(0, min(95, top_percent))
    h = monitor["height"]
    offset = int(h * top_percent / 100)
    return Region(monitor["left"], monitor["top"] + offset, monitor["width"], max(16, h - offset))


def parse_region(text: str) -> Tuple[int, int, int, int]:
    parts = [int(p) for p in text.replace(" ", "").split(",")]
    if len(parts) != 4:
        raise ValueError("Bölge 'x,y,genişlik,yükseklik' biçiminde olmalı")
    return parts[0], parts[1], parts[2], parts[3]


class ScreenGrabber:
    """mss ile ekran alanını BGR numpy dizisi olarak verir."""

    def __init__(self, monitor_index: int = 1):
        import mss  # noqa: PLC0415

        self._mss = mss.mss()
        monitors = self._mss.monitors  # [0]=tüm ekranlar, 1..n = tek tek
        if not 1 <= monitor_index < len(monitors):
            raise ValueError(f"Monitör {monitor_index} yok (1..{len(monitors) - 1} arası seç)")
        self.monitor = monitors[monitor_index]

    def grab(self, region: Region):
        import numpy as np  # noqa: PLC0415

        shot = self._mss.grab(
            {"left": region.left, "top": region.top, "width": region.width, "height": region.height}
        )
        arr = np.frombuffer(shot.bgra, dtype=np.uint8).reshape(shot.height, shot.width, 4)
        return arr[:, :, :3].copy()  # BGR

    def close(self) -> None:
        self._mss.close()


def mean_brightness(image) -> float:
    """Ortalama parlaklık (0..255). Tamamen siyah görüntü ~0."""
    return float(image[::8, ::8].mean())


def frames_equal(a, b) -> bool:
    """Seyrek örnekleyerek iki karenin aynı olup olmadığına bakar (aynıysa OCR atlanır)."""
    if a is None or b is None or a.shape != b.shape:
        return False
    return bool((a[::4, ::4] == b[::4, ::4]).all())


TEXT_LEVEL = 150      # bu parlaklığın üstü "yazı pikseli" sayılır (oyun altyazıları açık renk)
MIN_TEXT_PIXELS = 20  # ~2 piksel adımla örneklenmiş sayı; altındaysa karede altyazı yok


def text_box(image, pad: int = 12):
    """Parlak (yazı) piksellerin sınır kutusu: (üst, alt, sol, sağ) ya da altyazı yoksa None.

    OCR yalnızca bu kutuya uygulanır: boş kareler tamamen atlanır, dolu karelerde de aranacak alan küçülür.
    """
    import numpy as np  # noqa: PLC0415

    small = image[::2, ::2]
    mask = small.max(axis=2) > TEXT_LEVEL
    if int(mask.sum()) < MIN_TEXT_PIXELS:
        return None
    rows = np.flatnonzero(mask.any(axis=1))
    cols = np.flatnonzero(mask.any(axis=0))
    h, w = image.shape[0], image.shape[1]
    top = max(0, int(rows[0]) * 2 - pad)
    bottom = min(h, int(rows[-1]) * 2 + 2 + pad)
    left = max(0, int(cols[0]) * 2 - pad)
    right = min(w, int(cols[-1]) * 2 + 2 + pad)
    return top, bottom, left, right


class Ocr:
    """rapidocr-onnxruntime: pip dışında kurulum gerektirmeyen, çevrimdışı OCR."""

    MIN_SCORE = 0.5

    def __init__(self):
        from rapidocr_onnxruntime import RapidOCR  # noqa: PLC0415

        self._engine = RapidOCR()

    def read(self, image) -> str:
        box = text_box(image)
        if box is None:
            return ""  # karede açık renkli yazı yok: OCR çalıştırmaya gerek yok
        top, bottom, left, right = box
        result, _ = self._engine(image[top:bottom, left:right])
        return self.join_lines(result)

    @classmethod
    def join_lines(cls, result) -> str:
        """[[kutu, metin, güven], ...] -> yukarıdan aşağı, soldan sağa tek metin."""
        if not result:
            return ""
        items: List[Tuple[float, float, str]] = []
        for box, text, score in result:
            try:
                if float(score) < cls.MIN_SCORE:
                    continue
                ys = [p[1] for p in box]
                xs = [p[0] for p in box]
            except (TypeError, ValueError, IndexError):
                continue
            items.append((min(ys), min(xs), str(text)))
        items.sort()
        return " ".join(t for _, _, t in items)


def write_png(path: str, image) -> None:
    """BGR numpy dizisini PNG olarak kaydeder (Pillow gerekmez)."""
    h, w = image.shape[0], image.shape[1]
    rgb = image[:, :, ::-1]
    raw = b"".join(b"\x00" + rgb[y].tobytes() for y in range(h))

    def chunk(tag: bytes, data: bytes) -> bytes:
        body = tag + data
        return struct.pack("!I", len(data)) + body + struct.pack("!I", zlib.crc32(body) & 0xFFFFFFFF)

    png = (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack("!IIBBBBB", w, h, 8, 2, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(raw, 6))
        + chunk(b"IEND", b"")
    )
    with open(path, "wb") as f:
        f.write(png)
